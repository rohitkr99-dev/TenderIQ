import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/shared/Providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

import { GlobalAIAssistant } from "@/components/shared/global-ai-assistant";

export const metadata: Metadata = {
  title: "TenderIQ | AI-Powered Construction Tender Assistant",
  description: "Modern AI assistant for construction contractors, quantity surveyors, and procurement teams.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <Providers>
            {children}
            <GlobalAIAssistant />
        </Providers>
      </body>
    </html>
  );
}
